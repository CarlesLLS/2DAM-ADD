module com.example.sbuildermiercoles {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;
    requires java.logging;


    opens com.example.sbuildermiercoles to javafx.fxml;
    exports com.example.sbuildermiercoles;
}