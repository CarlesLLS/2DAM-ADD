package com.example.sbuildermiercoles;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HelloController implements Initializable {

    @FXML
    private TextField buscarid;
    @FXML
    private TextField buscarnombre;
    @FXML
    private TextField buscarequipo;
    @FXML
    private TextField buscaranyo;
    @FXML
    private TextField buscarposicion;
    @FXML
    private Button btncontinuar;
    @FXML
    private Button btnatras;

    Integer position;

    ApoyoXML datos = new ApoyoXML();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        position = 0;

        try
        {
            datos.LeerXML("datos.xml");

            FutbolistasPOJO Futbolistainicial = new FutbolistasPOJO();
            Futbolistainicial = datos.Read(0);
            buscarid.setText(String.valueOf(Futbolistainicial.getID()));
            buscarnombre.setText(Futbolistainicial.getNombre());
            buscarequipo.setText(Futbolistainicial.getEquipo());
            buscarequipo.setText(String.valueOf(Futbolistainicial.getAnyo()));
            buscarposicion.setText(Futbolistainicial.getPosicion());
        }
        catch (SAXException ex)
        {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (ParserConfigurationException ex)
        {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex)
        {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try
        {
            datos.EscribirXML("hola.xml");
        }
        catch (TransformerException ex)
        {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (ParserConfigurationException ex)
        {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}