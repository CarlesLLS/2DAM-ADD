package com.example.sbuildermiercoles;

import javafx.geometry.Pos;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ApoyoXML
{
    List<FutbolistasPOJO> listafutbolistas = new ArrayList<>();

    public void LeerXML(String path) throws SAXException, ParserConfigurationException, IOException
    {
        DocumentBuilderFactory bdFactory =DocumentBuilderFactory.newDefaultInstance();
        DocumentBuilder dbBuilder = bdFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));

        Element raiz = document.getDocumentElement();
        System.out.println("Contenido XML " + raiz.getNodeName() + ":");
        NodeList nodeList = document.getElementsByTagName("futbolista");

        for (int i=0;i<nodeList.getLength();i++)
        {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE)
            {
                Element eElement = (Element) node;
                FutbolistasPOJO futbolista = new FutbolistasPOJO();
                futbolista.setID(Integer.parseInt(eElement.getAttribute("id")));
                futbolista.setNombre(eElement.getElementsByTagName("Nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("Equipo").item(0).getTextContent());
                futbolista.setAnyo(Integer.parseInt(eElement.getAttribute("Anyo")));
                futbolista.setPosicion(eElement.getElementsByTagName("Posicion").item(0).getTextContent());
                listafutbolistas.add(futbolista);
            }
        }
    }

    public FutbolistasPOJO Read(int index)
    {
        return listafutbolistas.get(index);
    }

    public void Delete(int index)
    {
        listafutbolistas.remove(index);
    }

    /*
    public void Create(int id, String Nombre, String Equipo, int Anyo, String Posicion)
    {
        FutbolistasPOJO nuevo = new FutbolistasPOJO();
        nuevo.setID(listafutbolistas.size());
        nuevo.setNombre(Nombre);
        nuevo.setEquipo(Equipo);
        nuevo.setAnyo(Anyo);
        nuevo.setPosicion(Posicion);

        listafutbolistas.add(nuevo);
    }

    public void update(Integer position, String Nombre, String Equipo, int Anyo, String Posicion)
    {
        //listaNotas.get(position).setID(id);
        listafutbolistas.get(position).setNombre(Nombre);
        listafutbolistas.get(position).setEquipo(Equipo);
        listafutbolistas.get(position).setAnyo(Anyo);
        listafutbolistas.get(position).setPosicion(Posicion);
    }
    */
    public int registros()
    {
        return listafutbolistas.size();
    }

    public void EscribirXML(String path) throws TransformerConfigurationException, TransformerException,ParserConfigurationException
    {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        Element rootElement = doc.createElement("futbolistas");
        doc.appendChild(rootElement);

        for (FutbolistasPOJO futbolistas : listafutbolistas)
        {
            Element childElement = doc.createElement("futbolista");
            childElement.setAttribute("id", String.valueOf(futbolistas.getID()));

            rootElement.appendChild(childElement);

            Element nombre = doc.createElement("Nombre");
            nombre.appendChild(doc.createTextNode(futbolistas.getNombre()));
            childElement.appendChild(nombre);

            Element equipo = doc.createElement("Equipo");
            nombre.appendChild(doc.createTextNode(futbolistas.getNombre()));
            childElement.appendChild(equipo);

            Element anyo = doc.createElement("Anyo");
            anyo.appendChild(doc.createTextNode(String.valueOf(futbolistas.getAnyo())));
            childElement.appendChild(anyo);

            Element posicion = doc.createElement("Posicion");
            posicion.appendChild(doc.createTextNode(futbolistas.getPosicion()));
            childElement.appendChild(posicion);
        }

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();

        Properties outputProperties = new Properties();

        outputProperties.setProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        outputProperties.setProperty(OutputKeys.INDENT, "yes");
        outputProperties.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no");

        transformer.setOutputProperties(outputProperties);

        File xmlFile = new File(path);

        Result output = new StreamResult(xmlFile);
        transformer.transform(new DOMSource(doc), output);

        System.out.println("Archivo XML generado correctamente.");
    }

}
