package com.example.sbuildermiercoles;

public class FutbolistasPOJO
{
    int ID;
    String nombre;
    String equipo;
    int anyo;
    String posicion;

    public int getID() {
        return ID;
    }
    public void setID(int ID)
    {
        this.ID = ID;
    }


    public String getNombre()
    {
        return nombre;
    }
    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }


    public String getEquipo()
    {
        return equipo;
    }
    public void setEquipo(String equipo)
    {
        this.equipo = equipo;
    }


    public int getAnyo()
    {
        return anyo;
    }
    public void setAnyo(int anyo)
    {
        this.anyo = anyo;
    }


    public String getPosicion()
    {
        return posicion;
    }
    public void setPosicion(String posicion)
    {
        this.posicion = posicion;
    }



}
