package com.example.sbuildermiercoles;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args)
    {
        launch(args);
    }

    public void stop()
    {
        System.out.println("Stage is closing");
        // Save file
    }





    @FXML
    private void handleButtonActionPrevios(ActionEvent event)
    {

    }








    @FXML
    private void handleButtonActionDelete(ActionEvent event)
    {
    }

    @FXML
    private void handleButtonActionUpdate(ActionEvent event)
    {
    }
}